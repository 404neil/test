# Accessible PDF Reader & Translator

Upload a PDF, pick up to 10 pages (in any order), translate them into an
Indian language, and get audio (text read aloud) and/or a translated PDF —
usable by screen-reader users for text-to-speech access, and by anyone else
who wants a translated, downloadable/printable document.

Runs entirely in the browser (no backend). Users bring their own Sarvam AI
API key (BYOK) — it's used only for direct calls to `api.sarvam.ai` and is
never sent to or stored on any server.

## Required one-time setup: fonts

The translated-PDF output needs an actual font file for whichever Indic
script it's writing, because the PDF's default fonts only cover Latin
text — without this step, translated text will render as empty boxes.

1. Go to [Google Fonts](https://fonts.google.com) and download the **Noto
   Sans** family for each script you plan to support (e.g. Noto Sans
   Bengali, Noto Sans Devanagari, Noto Sans Tamil…).
2. From each downloaded family, take the **Regular** weight `.ttf` file.
3. Place them in this repo's `/fonts/` folder using these exact names
   (matched in `js/pdf-builder.js`):

   ```
   fonts/NotoSansDevanagari-Regular.ttf   (Hindi, Marathi)
   fonts/NotoSansBengali-Regular.ttf      (Bengali)
   fonts/NotoSansTamil-Regular.ttf        (Tamil)
   fonts/NotoSansTelugu-Regular.ttf       (Telugu)
   fonts/NotoSansGujarati-Regular.ttf     (Gujarati)
   fonts/NotoSansKannada-Regular.ttf      (Kannada)
   fonts/NotoSansMalayalam-Regular.ttf    (Malayalam)
   fonts/NotoSansGurmukhi-Regular.ttf     (Punjabi)
   fonts/NotoSansOriya-Regular.ttf        (Odia)
   ```

   You only need to add fonts for the languages you actually want to
   support — the app will show a clear error naming the missing file if a
   user picks a language whose font isn't there yet.

## Running locally

No build step. Because the app fetches font files and uses ES modules-ish
patterns, serve it over HTTP rather than opening `index.html` directly:

```bash
# from this folder
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this folder to a GitHub repo.
2. In the repo, go to **Settings → Pages**.
3. Under **Source**, choose the branch (e.g. `main`) and root folder.
4. Save — GitHub will give you a live URL within a minute or two.

## How it works

1. **pdf.js** renders page thumbnails and extracts text/images in-browser.
2. Pages with little or no embedded text (scanned pages) are OCR'd with
   **Tesseract.js**, also in-browser.
3. Extracted text is sent to Sarvam's `/translate` endpoint (Mayura model)
   using the user's own API key.
4. Translated (or original) text is sent to Sarvam's `/text-to-speech`
   endpoint (Bulbul model) if audio was requested.
5. **pdf-lib** + **fontkit** rebuild a clean, reflowed PDF from the
   translated text, with any extracted images placed in a "Figures &
   Tables" section at the end.

## Known limitations (v1)

- The translated PDF is a **reflow**, not a layout-preserving copy — text
  is laid out fresh, and original images/tables are grouped in a
  trailing section rather than positioned exactly where they appeared.
  Preserving original layout precisely is a much harder problem;
  documenting this as a deliberate scope decision (with layout
  preservation as future work) is completely reasonable for a
  dissertation-stage prototype.
- Long documents are handled in batches — up to 10 user-selected pages
  processed at a time, to keep client-side memory/processing and API
  usage predictable.
- Table structure isn't reconstructed — tables are currently extracted
  as images, not as re-flowable table objects.
